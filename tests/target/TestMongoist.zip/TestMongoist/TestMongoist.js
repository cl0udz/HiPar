"use strict";
var utils = require('../TestcaseUtils.js')
var mongoist = require("mongoist");
async function testinsert(query){
    var db = mongoist('mongodb://localhost:27017/test2');
    await db.b.insert(query);
    await db.close();
}
async function testfind(query){
    var db = mongoist('mongodb://localhost:27017/test2');
    await db.b.find(query);
    await db.close();
}
function main() {
    utils.entry(testinsert, { 'a': 3 });
    utils.entry(testfind, { 'a': 3 })

}

main();
