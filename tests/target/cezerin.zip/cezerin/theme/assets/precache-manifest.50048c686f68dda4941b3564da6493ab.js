self.__precacheManifest = [
  {
    "url": "/assets/js/theme-b07c9a208b654873ae2d.js"
  },
  {
    "url": "/assets/js/app-a8e8eb6aa38c3c818458.js"
  },
  {
    "revision": "b07c9a208b654873ae2d",
    "url": "/assets/css/bundle-436ebb6547e885058176.css"
  }
];