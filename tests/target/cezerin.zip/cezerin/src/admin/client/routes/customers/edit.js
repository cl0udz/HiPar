import React from 'react';
import CustomerDetails from 'modules/customers/edit';

export default CustomerDetails;
