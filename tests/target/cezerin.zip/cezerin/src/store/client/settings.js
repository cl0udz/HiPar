import settings from '../../../config/store';
export default settings;
