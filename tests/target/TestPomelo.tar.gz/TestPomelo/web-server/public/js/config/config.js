__resources__["/config.js"] = {meta: {mimetype: "application/javascript"}, data: function(exports, require, module, __filename, __dirname) {
	module.exports = {
		IMAGE_URL:'http://pomelo.netease.com/art/',
		GATE_HOST: window.location.hostname,
		GATE_PORT: 3014
	};
}};
