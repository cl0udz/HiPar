var cpus = os.cpus();
result = util.inspect(cpus,true,null);