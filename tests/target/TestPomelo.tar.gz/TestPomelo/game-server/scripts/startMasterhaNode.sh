#!/usr/bin/env bash
pomelo masterha /config/masterha.json
