var should = require('should');
var world = require('../../app/domain/world');

