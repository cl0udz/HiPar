# 官方代码 ISSUE

- [mimi.lookup is not a function] (https://github.com/broofa/node-mime/blob/1f0af634b97fa47e6e3f603a303e49b40b4c511c/mime.js) (版本更新造成api方法变动)
- [callback is not a function ]() (genertic-pool版本更新造成api 变动，修改详见dao-pool.js, mysql.js)

## 参考资料
- [mime](https://github.com/broofa/node-mime/blob/1f0af634b97fa47e6e3f603a303e49b40b4c511c/mime.js)
- [generic-pool](https://github.com/coopernurse/node-pool)